package ST10190700_PROG5121TASK1;


import javax.swing.*;
import java.util.Locale;
import java.util.Objects;
import java.util.Scanner;
/*Username condition:
1.Must contain an underscore.
2.Must be no more than 5 character long.
if True:"Username successfully captured"
if false:"Username is not correctly formatted,please ensure that username contains an underscore and is no more than 5
characters in length."

Password Conditions:
1.At least 8 characters
 2.Contains a capital letter
 3.Contain a number
 4.contains a special character

 if true: "password successfully captured"
 if False:"password is not correctly formatted,Please ensure that the password contains at least 8 characters,A capital
 letter,a number and a special character."
 */

public class Main {
    //All the scanners I'll be using for the program
    static Scanner user = new Scanner(System.in);//one for the username collection and usage.
    static Scanner pass = new Scanner(System.in);//one for password collection and usage.
    static Scanner login = new Scanner(System.in);//One for the login procedure.
    int total = 0;
    static String[] Developer;
    static String[] taskName;
    static String[] taskID;
    static int[] taskDuration;
    static int[] taskStatus;

    public static boolean checkUserName(String userNameGiven) {
        //this is where the username is checked to see if it meets the required conditions:having an underscore and being no more than 5 characters.
        //if the username given is more than 5 characters OR does not contain an underscore,
        //but when both conditions are true the return boolean value of true.
        return userNameGiven.length() <= 5 && userNameGiven.contains("_");                                             //then return boolean value of false
    }

    public static boolean checkPasswordComplexity(String passwordGiven) {
        boolean isCap = false;         //this section is dedicated to password verification.these are all my declarations and initializations.
        boolean isNum = false;
        boolean isSpecialChar = false;
        int i;
        int numCount = 0;
        int capCount = 0;
        int specCharCount = 0;
        for (i = 0; i < passwordGiven.length(); ++i) { //this for loop scans through the string(Password) and records the occurrence of Capital letters,
            char c = passwordGiven.charAt(i);          //numbers and special characters using their character index(Avicii table)
            if (c >= 65 && c <= 90) {//if there's an occurrence of a capital letter,then my int variable capCount will be incremented by 1.I'm calling these occurrences.
                ++capCount;
            }
            if (c >= 48 && c <= 57) {//if there's an occurrence of a number,then my int variable numCount will be incremented by 1.
                ++numCount;
            }
            if ((c >= 58 && c <= 64) || (c >= 32 && c <= 47) || (c >= 91 && c <= 96) || (c >= 123 && c <= 126)) {//if there's an occurrence of a special character,then my int variable specCharCount will be incremented by 1.
                ++specCharCount;
            }
        }

        if (capCount >= 1) { //if there's an occurrence of a capital letter,then my boolean of isCap will become true.
            isCap = true;
        }
        if (numCount >= 1) { //if there's an occurrence of a Number,then my boolean of isNum will become true.
            isNum = true;
        }
        if (specCharCount >= 1) { //if there's an occurrence of a Special character,then my boolean of isSpecialChar will become true.
            isSpecialChar = true;
        }

        if (isCap && isNum && isSpecialChar && passwordGiven.length() >= 8) { //if all occurrence become true then this boolean Method will return true,
            return true;
        }
        //else it will return false.
        return isNum && isCap && passwordGiven.length() >= 8;
    }

    public static String registerUser() {
        return "the two above conditions have been met and the user has been registered successfully. ";//because of my usage of while loops to give the user multiple attempts at the password and username creation,
    }                                                                                                   //this method can only be true,or is inevitably going to happen.

    public static void main(String[] args) {
          //first name input
            System.out.println("welcome to the registration page,we just going to need a few thing from you");
            System.out.println("please provide your first name,last name,a Username and a password.");
            Scanner input = new Scanner(System.in);
            System.out.println("please enter your First Name: ");//prompting user for their first name.
            String firstName = input.next();//saving the user input as a string variable.

            Scanner surname = new Scanner(System.in);
            System.out.println("please enter your Last Name: ");//prompting user for their last name.
            String lastName = surname.next();//saving the user input as a string variable.

            System.out.println("now we will need you to create a username that is less than 5 characters and must include" +
                    " an underscore('_')");
            System.out.println("please enter a suitable username: ");//prompting user for a username.
            String userInput = user.next();//saving the user input as a string variable.
            System.out.println(checkUserName(userInput));//running the user input though my username verification method or checkUserName().
            //depending on the result of the boolean method(checkUserName()),either true or false,Then this section will output the corresponding statement.
            if (checkUserName(userInput)) {  //if true,then print out thr following statement.
                System.out.println("Username successfully captured");
            }
            while (!checkUserName(userInput)) { //if false,then print out the following statement, that give the user another chance at creating a username.
                System.out.println("Username is not correctly formatted,please ensure that username contains an underscore and is no more than 5 characters in length.");
                userInput = user.next();
            }

            System.out.println("Great,time to create a Password.Password Requirements:Must be at least 8 characters long");
            System.out.println("                                                      Must contain a Capital letter");
            System.out.println("                                                      Must contain a number");
            System.out.println("                                                      Must contain a special character");
            System.out.println("please enter a suitable Password: ");//prompting user for a password.
            String userGivenPassword = pass.next();//saving the user input as a string variable.
            System.out.println(checkPasswordComplexity(userGivenPassword));//running the user input though my password verification method or checkPasswordComplexity().
            //depending on the result of the boolean method(checkPasswordComplexity()),either true or false,Then this section will output the corresponding statement.
            while (!checkPasswordComplexity(userGivenPassword)) { //if false,then print out the following statement, that give the user another chance at creating a password.
                System.out.println("password is not correctly formatted,Please ensure that the password contains at least 8 characters,A capital letter,a number and a special character");
                userGivenPassword = pass.next();
            }
            if (checkPasswordComplexity(userGivenPassword)) { //if true,then print out thr following statement.
                System.out.println("password successfully captured");
            }
            //when both the password and username have been completed then,my registerUser method will be called.
            System.out.println(registerUser());
            System.out.println("--------------------------------------------------------------------------------------------------------------------");
            System.out.println("welcome to the login page");
        /*login to account using the same password and username
        in this section,I have a boolean method that checks if the username and password given are consistent or the same as the one created by the user.This is how they log in to
         their accounts */
           if (LoginUser(userInput, userGivenPassword)) { //my method is called within my if condition and depending on its result(true or false),then a corresponding statement will be called upon.
                System.out.println("A successful login.");//this is executed when my boolean returns true.
                System.out.println("Welcome " + firstName + " " + lastName + " " + "it is great to see you again");
                int optionChoose = Integer.parseInt(JOptionPane.showInputDialog("Welcome to EasyKanban \nOption 1) Add task \nOption 2)Show report \nOption 3) Quit "));//this JOptionPane pop-up prompts the using into select ome of three options.I saved it as
                //an integer so I could use the user's response to execute the corresponding action according to the users selected option.

                while (optionChoose<3) {//I begin this loop in order for the program to execute indefinitely till the user decide to Quit.
                    if (optionChoose == 2) {//this executes if the user selects option 2) that being show report.
                        int choice = Integer.parseInt(JOptionPane.showInputDialog("""
                                1. Display the Developer, Task Names and Task Duration for all tasks with the status of done.
                                2. Display the Developer and Duration of the task with the longest duration.
                                3. Search for a task with a Task Name and display the Task Name, Developer and Task Status.
                                4. Search for all tasks assigned to a developer and display the Task Name and Task Status.
                                5. Delete a task using the Task Name.
                                6. Display a report that lists the full details of all captured tasks.
                                7.back
                                """));
                        while (choice<7) {
                            if (choice == 1) {
                                JOptionPane.showMessageDialog(null, task3.DoneDisplay(taskStatus, taskDuration, Developer, taskName));
                            }
                            if (choice == 2) {
                                JOptionPane.showMessageDialog(null, task3.longestDuration(taskDuration, Developer));
                            }
                            if (choice == 3) {
                                String taskSearched = JOptionPane.showInputDialog(null, "please enter the task name: ");
                                JOptionPane.showMessageDialog(null, task3.taskNameSearch(taskName, Developer, taskStatus, taskSearched));
                            }
                            if (choice == 4) {
                                String nameSearched = JOptionPane.showInputDialog(null, "please enter the name of the developer who's tasks you are looking for: ");
                                JOptionPane.showMessageDialog(null, task3.SearchDeveloper(Developer, taskName, taskStatus, nameSearched));
                            }
                            if (choice == 5) {
                                String deleteTask = JOptionPane.showInputDialog(null, "Enter the task you are trying to delete.");
                                task3.deleteElement(deleteTask);
                            }
                            if (choice == 6) {
                                JOptionPane.showMessageDialog(null, task3.ShowReport(Developer, taskName, taskStatus, taskID, taskDuration));
                            }
                            choice = Integer.parseInt(JOptionPane.showInputDialog("""
                                1. Display the Developer, Task Names and Task Duration for all tasks with the status of done.
                                2. Display the Developer and Duration of the task with the longest duration.
                                3. Search for a task with a Task Name and display the Task Name, Developer and Task Status.
                                4. Search for all tasks assigned to a developer and display the Task Name and Task Status.
                                5. Delete a task using the Task Name.
                                6. Display a report that lists the full details of all captured tasks.
                                7.back
                                """));
                        }

                    }
                    Main prod=new Main();//I created this object in order to call my non-static returnTotalHours().
                    if (optionChoose == 1) {//this executes when th use choose to add Tasks.
                        int taskNum=Integer.parseInt(JOptionPane.showInputDialog(null,"How many tasks do you wish to complete: "));
                        String[] dev=new String[taskNum];
                        String[] taskN=new String[taskNum];
                        String[]  ID=new String[taskNum];
                        int[] Dura=new int[taskNum];
                        int[] Status=new int[taskNum];

//prompts user to enter the number of task they want to add,this is also the number of iterations that the following loop will adhere to.

                        for (int i = 0; i < taskNum; ++i) {// this For Loop gathers all the information from the user and distributes this information to all my methods that execute certain actions.
                            taskN[i] = JOptionPane.showInputDialog(null,"Please enter the name of your task: ");//name of task information collection.

                           String descrip =JOptionPane.showInputDialog("Please provide a description of said task: ");//task description collection.


                            while (!checkTaskDescription(descrip)) {//if said task description is more than 50 characters long  than
                                descrip =JOptionPane.showInputDialog("Please enter a Task description of less than 50 characters");//this will pop up and give the user another chance to enter a suitable Task Description.

                            }
                            if (checkTaskDescription(descrip)) {
                                JOptionPane.showMessageDialog(null,"Task successfully captured");//this message pops up when the task description fits the conditions in place.
                            }

                             dev[i]=JOptionPane.showInputDialog("Developer Details\nwhat is your name? ");//name of Developer information collection.

                            String devSurname= JOptionPane.showInputDialog("please enter your surname: ");//surname of developer information collection.


                            Dura[i] =  Integer.parseInt(JOptionPane.showInputDialog("please enter your estimated task duration in hours: "));//task duration information collection.

                            ID[i] = createTaskID(taskN[i], dev[i], i);//this is the created Task ID saved as a string for later use.

                            Status[i] =  Integer.parseInt(JOptionPane.showInputDialog("Task Status\nPlease provide your task status: \n1)To Do\n2)Done\n3)Doing"));//User's task status is recorded.
                            JOptionPane.showMessageDialog(null,printTaskDetail(Status[i], descrip, i, taskN[i], dev[i], Dura[i], ID[i],devSurname));//all information is put though my printTaskDetails() to be organised and displayed to the user.


                            JOptionPane.showMessageDialog(null,"Total estimated hours - "+prod.returnTotalHours(Dura[i]));//this shows the total estimated time of completion for all tasks.
                        }

                        taskID=ID;
                        taskStatus=Status;
                        taskName=taskN;
                        Developer= dev;
                        taskDuration=Dura;
                    }
                    optionChoose = Integer.parseInt(JOptionPane.showInputDialog("Welcome to EasyKanban \nOption 1) Add task \nOption 2)Show report \nOption 3) Quit "));

                }

                if (optionChoose==3){
                    JOptionPane.showMessageDialog(null,"thank you");
                }
            }
            else {//this is executed when my boolean returns false.
                System.out.println("A unsuccessful login");
                System.out.println("Username or password incorrect,please try again");
            }

    }

    public static boolean LoginUser(String U, String Pass) {
        //prompt to user
        System.out.println("Please enter your username: ");
        String loginUser = login.next();

        System.out.println("Please enter your Password: ");
        String loginPass = login.next();
        //if both the loginUser and username match, then this method will return true,same in regard to the password.but if none of them match,then this method will return false.
        return Objects.equals(loginUser, U) && Objects.equals(loginPass, Pass);
    }

    public static Boolean checkTaskDescription(String T){//this method checks the String(task description) length and either return a true or false boolean value depending on the string length being less than or more than 50.
        return T.length() < 50;
    }

    public static String createTaskID(String task,String Name,int y){//this method takes in the task name,developer name and i(being my auto-generated number) and creates a Task ID.
        return task.substring(0,2).toUpperCase(Locale.ROOT)+":"+y+":"+Name.substring(Name.length()-3).toUpperCase(Locale.ROOT);
    }
    public static String printTaskDetail(int TStatus,String details,int x,String TName,String Name,int HDuration,String ID,String surName){//this method prints out the task details according to all the information given by the user.
        String one ="To do";//these are my string constants for task Status and in correlation to what the user has select then TStatus will change to one of these.
        String two="Done";
        String three="Doing";
        String taskStatus;
        if(TStatus==1){
            taskStatus=one;
            return  "task status: "+taskStatus+"\n"+"Developer Details\nDeveloper's name: "+Name+" "+surName+"\n"+"task number: "+x+"\n"+"Task name:"+TName+"\n"+"task description: "
                    + details+"\n"+"Task ID: "+ID+"\n"+"estimated duration in hours: "+HDuration;//this is the formatted message the is return for when the 1st task status.
        }
        if(TStatus==2){
            taskStatus=two;
            return "task status: "+taskStatus+"\n"+"Developer Details\nDeveloper's name: "+Name+" "+surName+"\n"+"task number: "+x+"\n"+"Task name:"+TName+"\n"+"task description: "
                    + details+"\n"+"Task ID: "+ID+"\n"+"estimated duration: "+HDuration;//this is the formatted message the is return for when the 2nd task status.
        }
        if(TStatus==3){
            taskStatus=three;
            return "task status: "+taskStatus+"\n"+"Developer Details\nDeveloper's name: "+Name+" "+surName+"\n"+"task number: "+x+"\n"+"Task name:"+TName+"\n"+"task description: "
                    + details+"\n"+"Task ID: "+ID+"\n"+"estimated duration: "+HDuration;//this is the formatted message the is return for when the 3rd task status.
        }
        return "";
    }

    public int returnTotalHours(int duration){//this calculates the total hours required for all the tasks.
        total+=duration;
        return total;
    }

}

