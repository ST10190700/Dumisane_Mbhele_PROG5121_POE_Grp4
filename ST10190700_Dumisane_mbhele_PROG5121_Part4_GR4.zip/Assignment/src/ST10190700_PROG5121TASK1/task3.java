package ST10190700_PROG5121TASK1;

import javax.swing.*;

public class task3 {
public static String DoneDisplay(int[] status,int[] taskDuration,String[] dev,String[] taskName){
  int pos;
  for (int i = 0; i < status.length; i++) {
    if(status[i]==2){
      pos=i;
      JOptionPane.showMessageDialog(null,"Task Duration: "+taskDuration[pos]+"  hours"+"\nTask name: "+taskName[pos]+"\nDeveloper: "+dev[pos]);
    }
  }
  return "done";
}
public static String longestDuration(int[] tDuration,String[] dev){
  int pos2;
  int max=tDuration[0];
  for (int i = 0; i < tDuration.length; i++) {
    if(tDuration[i]>max){
      max=tDuration[i];
      pos2=i;
      return "Developer: "+dev[pos2]+"\nLongest Duration:"+max;
    }
  }
  return null;
}
public static String taskNameSearch(String[] tName,String[] dev,int[] status,String nameGiven){
  String one ="To do";
  String two="Done";
  String three="Doing";
  String taskStatus;
  int pos3;
  for (int i = 0; i < tName.length; i++) {
    if(tName[i].equalsIgnoreCase(nameGiven)){
      pos3=i;
      if(status[pos3]==1){
        taskStatus=one;
        return "Task Name: "+nameGiven+"\nDeveloper: "+dev[pos3]+"\nTask Status: "+taskStatus;
      }
      if(status[pos3]==2){
        taskStatus=two;
        return "Task Name: "+nameGiven+"\nDeveloper: "+dev[pos3]+"\nTask Status: "+taskStatus;
      }
      if(status[pos3]==3){
        taskStatus=three;
        return "Task Name: "+nameGiven+"\nDeveloper: "+dev[pos3]+"\nTask Status: "+taskStatus;
      }
    }
  }
  return "";
}

public static String SearchDeveloper(String[] dev,String[] tName,int[] status,String name){
  String one ="To do";
  String two="Done";
  String three="Doing";
  String taskStatus;
  int pos3;
  for (int i = 0; i < dev.length; i++) {
    if(dev[i].equalsIgnoreCase(name)){
      pos3=i;
      if(status[pos3]==1){
        taskStatus=one;
        JOptionPane.showMessageDialog(null,"Developer: "+name+"\nTask Name: "+tName[pos3]+"\nTask Status: "+taskStatus);
      }
      if(status[pos3]==2){
        taskStatus=two;
        JOptionPane.showMessageDialog(null,"Developer: "+name+"\nTask Name: "+tName[pos3]+"\nTask Status: "+taskStatus);
      }
      if(status[pos3]==3){
        taskStatus=three;
        JOptionPane.showMessageDialog(null,"Developer: "+name+"\nTask Name: "+tName[pos3]+"\nTask Status: "+taskStatus);
      }

      }
  }
  return "search done";
}

public static void deleteElement(String TaskDeleted ){
    String[] newTN=new String[Main.taskName.length-1];
    String[] newDev=new String[Main.Developer.length-1];
    int[] newDura= new int[Main.taskDuration.length - 1];
    int[] newStatus=new int[Main.taskStatus.length-1];
    String[] newID=new String[Main.taskID.length-1];

    int x=0;
    int pos=0;
  for (int i = 0; i < Main.taskName.length; i++) {
    if(Main.taskName[i].equalsIgnoreCase(TaskDeleted)) {
      pos = i;
    }
    else{
      newTN[x]=Main.taskName[i];
      ++x;
    }

    int y = 0;
    for (int k = 0; k < Main.taskDuration.length; k++) {
      if (k != pos) {
        newDura[y] = Main.taskDuration[k];
        newID[y] = Main.taskID[k];
        newStatus[y] = Main.taskStatus[k];
        newDev[y] = Main.Developer[k];
        y++;
      }
    }
    Main.taskDuration=newDura;
    Main.taskID=newID;
    Main.taskStatus=newStatus;
    Main.Developer=newDev;
    Main.taskName=newTN;
    
   JOptionPane.showMessageDialog(null,"Entry "+ TaskDeleted+" successfully deleted");

    }

}

public static String ShowReport(String[] dev,String[] tName,int[] status,String[] ID,int[] dura){
  String one ="To do";
  String two="Done";
  String three="Doing";
  String taskStatus;
  for (int i = 0; i < dev.length; i++) {
      if(status[i]==1){
        taskStatus=one;
        JOptionPane.showMessageDialog(null,"Developer: "+dev[i]+"\nTask Name: "+tName[i]+"\nTask Status: "+taskStatus+"\nTask ID: "+ID[i]+"\nTask Duration: "+dura[i]);
      }
      if(status[i]==2){
        taskStatus=two;
        JOptionPane.showMessageDialog(null,"Developer: "+dev[i]+"\nTask Name: "+tName[i]+"\nTask Status: "+taskStatus+"\nTask ID: "+ID[i]+"\nTask Duration: "+dura[i]);
      }
      if(status[i]==3){
        taskStatus=three;
        JOptionPane.showMessageDialog(null,"Developer: "+dev[i]+"\nTask Name: "+tName[i]+"\nTask Status: "+taskStatus+"\nTask ID: "+ID[i]+"\nTask Duration: "+dura[i]);

      }

    }
  return "end report";
}



  }




