package ST10190700_PROG5121TASK1;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class task3Test {

	@Test
	void testDoneDisplay() {
		fail("Not yet implemented");
	}

	@Test
	void testLongestDuration() {
		fail("Not yet implemented");
	}

	@Test
	void testTaskNameSearch() {
		fail("Not yet implemented");
	}

	@Test
	void testSearchDeveloper() {
		fail("Not yet implemented");
	}

	@Test
	void testDeleteElement() {
		fail("Not yet implemented");
	}

	@Test
	void testShowReport() {
		fail("Not yet implemented");
	}

}
