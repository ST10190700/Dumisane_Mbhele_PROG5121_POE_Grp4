package ST10190700_PROG5121TASK1;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class taskTests {
static String[] Developer= {"Mike Smith","Edward Harrison","Samantha Paulson","Glenda Oberholzer"};
static String[] taskName= {"Create Login","Create add features","Create reports","Add arrays"};
static int[] taskDuration= {5,8,2,11};
static int[] Status= {1,3,2,1};

	@Test
	void test() {
		Main test = new Main();
		String taskID = test.createTaskID("Login Feature", "Robyn", 0);
		assertEquals("LO:0:BYN", taskID);
	}

	void test2() {
		Main test = new Main();
		boolean taskDescription = test.checkTaskDescription("Create login to authenticate users");
		assertEquals(true, taskDescription);
	}

	void test3() {
		Main test = new Main();
		boolean taskDescription = test.checkTaskDescription(
				"Create login to authenticate users jhhhssuhshhihihiuhuuihiuihikikhihiuhhuhuhuihuihuuhuuhuhiuhuhuhiuuhiuuhuihihihini  7 y778y78iuikhjuijhuiijoibgyuyu7thyytfgyggyuhyiguhgtyuhgyh");
		assertEquals(false, taskDescription);
	}

	void test4() {
		Main test = new Main();
		boolean password = test.checkPasswordComplexity("Ch&&sec@ke99!");
		assertEquals(true, password);
	}

	void test5() {
		Main test = new Main();
		boolean password = test.checkPasswordComplexity("password");
		assertEquals(false, password);
	}

	void test6() {
		Main test = new Main();
		boolean username = test.checkUserName("kyl_1");
		assertEquals(true, username);
	}

	void test7() {
		Main test = new Main();
		boolean username = test.checkUserName("kyle!!!!!!!!");
		assertEquals(false, username);
	}
	void testDoneDisplay() {
		task3 test=new task3();
		String done=test.DoneDisplay(Status, taskDuration, Developer, taskName);
		assertEquals("done",done);
		
	}

	@Test
	void testLongestDuration() {
		task3 test2=new task3();
		String Max=test2.longestDuration(taskDuration, Developer);
		assertEquals("Developer: "+"Glenda Oberholzer"+"\nLongest Duration:"+11,Max);
	}

	@Test
	void testTaskNameSearch() {
		String task="Create login";
		task3 test3=new task3();
		String taskFind=test3.taskNameSearch(taskName, Developer, Status, task);
		assertEquals("Task Name: "+task+"\nDeveloper: "+Developer[1]+"\nTask Status: "+Status[1],taskFind);
	}

	@Test
	void testSearchDeveloper() {
		String devSearch="Samantha Paulson";
		task3 test4=new task3();
		String result=test4.SearchDeveloper(Developer, taskName, Status, devSearch);
		assertEquals("search done",result);
	}

}
